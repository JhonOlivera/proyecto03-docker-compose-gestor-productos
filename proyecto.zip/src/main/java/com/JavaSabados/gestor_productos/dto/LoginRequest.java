package com.JavaSabados.gestor_productos.dto;

public class LoginRequest {

    //atributos
    private String email;
    private String password;

    //getters and setters

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
